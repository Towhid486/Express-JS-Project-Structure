// Create
export const createTask = async (req, res) =>{
    return res.json({message:'Task created successfully'});
}


// Read
export const readTask = async (req, res) =>{
    return res.json({message:'Task read successfully'});
}


// Update
export const updateTask = async (req, res) =>{
    return res.json({message:'Task update successfully'});
}


// Delete
export const deleteTask = async (req, res) =>{
    return res.json({message:'Task delete  successfully'});
}